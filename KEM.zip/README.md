# KEM project manager (kem)

KEM project manager

## Install the dependencies
```bash
npm install
```

### Start the app in development mode (hot-code reloading, error reporting, etc.)
```bash
quasar dev
```


### Build the app for production
```bash
quasar build
```
### Demo
[PROMAN](http://proman.surge.sh)
