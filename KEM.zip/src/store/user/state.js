export default function () {
  return {
    user:null,
    token:null,
    isUserLoggedIn: false
  }
}
