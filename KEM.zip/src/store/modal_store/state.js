export default function () {
  return {
    //
    new_task_modal: false,
    new_project_modal: false,
    new_team_modal: false,

    view_project_modal: false,
    view_task_modal: false,
    view_task_data: false,
    
    new_status_modal: false,
  }
}
