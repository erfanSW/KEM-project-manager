/*
export function someGetter (state) {
}
*/
export function loadprojects(state) {
  return state.loadprojects
}
