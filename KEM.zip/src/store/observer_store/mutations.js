/*
export function someMutation (state) {
}
*/

export function loadprojects_toggle (state) {
  state.loadprojects = !state.loadprojects
}
