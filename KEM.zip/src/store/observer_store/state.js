export default function () {
  return {
    loadprojects: false,
  }
}
