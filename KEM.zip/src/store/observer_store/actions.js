/*
export function someAction (context) {
}
*/
export function loadprojects_toggle({commit}) {
  commit('loadprojects_toggle')
}
